package com.ict.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ict.persistence.MovieVO;
import com.ict.service.MovieService;

// 컨트롤러 세팅
@Controller
@RequestMapping("/movie")
public class MovieController {

	// 컨트롤러는 서비스를 호출합니다.
	@Autowired
	private MovieService service;
	
	// 메서드를 만들어주세요.
	// get방식으로 접속하고 전체 영화 목록을 result.jsp에 출력하도록 세팅해주세요.
	@GetMapping("/allMovies")
	public String getMovieResults(Model model) {
		// 전체 영화 목록을 가져옵니다.
		List<MovieVO> movieList = service.getAllMovies();
		
		model.addAttribute("movieList", movieList);
		return "movie/result";
	}
	
	
	
}
