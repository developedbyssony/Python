package com.ict.persistence;

import lombok.Data;

@Data
public class Criteria {
	
	private int page;
	private int number = 10;
	
}
