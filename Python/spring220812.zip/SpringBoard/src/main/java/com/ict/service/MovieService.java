package com.ict.service;

import java.util.List;

import com.ict.persistence.MovieVO;

public interface MovieService {

	// 전체 목록 가져오기 메서드 선언만
	public List<MovieVO> getAllMovies();
}
