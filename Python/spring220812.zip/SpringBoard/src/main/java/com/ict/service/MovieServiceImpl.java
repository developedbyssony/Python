package com.ict.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ict.mapper.MovieMapper;
import com.ict.persistence.MovieVO;

@Service
public class MovieServiceImpl 
		implements MovieService {
	
	// 서비스는 Mapper를 호출하므로 생성
	@Autowired
	private MovieMapper mapper;
	
	// Service에 적힌 메서드 구현
	@Override
	public List<MovieVO> getAllMovies() {
		return mapper.getAllMovies();
	}


	
	
}
