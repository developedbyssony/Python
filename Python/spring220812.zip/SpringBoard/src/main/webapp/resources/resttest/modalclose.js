$("#closeBtn").on("click", function(){
	$("#modDiv").hide("slow");
});