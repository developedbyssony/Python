package com.ict.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.extern.log4j.Log4j;

//테스트 코드를 작성해서 getAllMovies가 작동하는지 체크해주세요.

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class MovieMapperTests {

	// 테스트를 돌리기 위해 Mapper 선언 및 주입.
	@Autowired
	private MovieMapper mapper;
	
	// 전체 데이터를 가져오는 getAllMovies를 실행한 다음, 결과를 log.info로 조회
	@Test
	public void getListTest() {
		log.info(mapper.getAllMovies());
	}
	
}
