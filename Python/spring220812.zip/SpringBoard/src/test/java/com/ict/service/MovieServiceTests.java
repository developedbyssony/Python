package com.ict.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ict.mapper.MovieMapperTests;

import lombok.extern.log4j.Log4j;

// MovieMapperTests를 참조해 테스트코드를 작성해주요.

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class MovieServiceTests {

	// 서비스 구현체 생성 및 의존성 주입
	@Autowired
	private MovieService service;
	
	// 메서드 작성
	@Test
	public void getList() {
		log.info(service.getAllMovies());
	}
	
}


